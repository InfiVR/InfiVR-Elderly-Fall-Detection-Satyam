import cv2
import mediapipe as mp
import numpy as np
from tkinter import Tk, Button, filedialog, Label, Toplevel, Listbox, Scrollbar
import logging
import os
import sys
import threading
import requests
from datetime import datetime

# Setup logging
logging.basicConfig(
    filename="fall_detector.log",  # Log file
    level=logging.DEBUG,  # Log all levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format="%(asctime)s [%(levelname)s] %(message)s",  # Format for log messages
)
logging.info("Program started.")

# Global variable for video source
video_source = None

# Mediapipe setup
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

def resource_path(relative_path):
    try:
        base_path=sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path,relative_path)

# Function to calculate the angle between three points
def calculate_angle(a, b, c):
    try:
        a = np.array(a)  # First
        b = np.array(b)  # Mid
        c = np.array(c)  # End

        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
        angle = np.abs(radians * 180.0 / np.pi)

        if angle > 180.0:
            angle = 360 - angle

        logging.debug(f"Calculated angle: {angle}")
        return angle
    except Exception as e:
        logging.error(f"Error in calculate_angle: {e}")
        return None

import requests
from datetime import datetime

def get_current_datetime():
    now = datetime.now()
    return now.strftime("%m/%d/%y,%H:%M:%S")

def send_message():
    url = "http://elderly-healthcare.infivr.com/api/events/create"
    payload = {
        "eventName": "Fall",
        "userName": "Satyam",
        "applicationName": "FALL_DETECTOR",
        "eventTime": get_current_datetime(),
        "severity": "high",
        "sensorId": "1"
    }
    headers = {}
    response = requests.request("POST", url, headers=headers, data=payload)
    print(response.text)

# Function to list all available cameras
def list_cameras():
    try:
        index = 0
        available_cameras = []
        while True:
            cap = cv2.VideoCapture(index)
            if not cap.read()[0]:  # If the camera cannot be opened, stop checking
                break
            available_cameras.append(f"Camera {index}")
            cap.release()
            index += 1
        logging.info(f"Available cameras: {available_cameras}")
        return available_cameras
    except Exception as e:
        logging.error(f"Error in list_cameras: {e}")
        return []


# Function to open a new window to select a camera
def select_camera_window():
    global video_source

    try:
        # Create a new window
        camera_window = Toplevel(root)
        camera_window.title("Select Camera")
        camera_window.geometry("300x300")

        # Label
        label = Label(camera_window, text="Select a Camera", font=("Helvetica", 12))
        label.pack(pady=10)

        # Listbox to show available cameras
        camera_listbox = Listbox(camera_window, width=30, height=10)
        camera_listbox.pack(pady=10)

        # Add a scrollbar
        scrollbar = Scrollbar(camera_window, orient="vertical", command=camera_listbox.yview)
        scrollbar.pack(side="right", fill="y")
        camera_listbox.config(yscrollcommand=scrollbar.set)

        # List available cameras
        cameras = list_cameras()
        for cam in cameras:
            camera_listbox.insert("end", cam)

        # Function to set the selected camera and close the window
        def confirm_camera():
            selected_index = camera_listbox.curselection()
            if selected_index:
                video_source = int(selected_index[0])  # Get the camera index
                camera_window.destroy()  # Close the camera selection window
                root.destroy()  # Close the main window
                logging.info(f"Selected camera: {video_source}")
                fall_detection_system(video_source)

        # Button to confirm the selection
        confirm_button = Button(camera_window, text="Confirm", command=confirm_camera)
        confirm_button.pack(pady=10)

    except Exception as e:
        logging.error(f"Error in select_camera_window: {e}")


# Function to process the fall detection system
# Function to calculate the centroid of all joint points
# Threshold for Y-difference
y_DIFF_THRESHOLD = 0.01  # Adjust this value based on the scaling of your coordinate system
# Function to calculate the centroid of a list of points
def calculate_centroid(points):
    try:
        x_coords = [point[0] for point in points]
        y_coords = [point[1] for point in points]
        centroid_x = np.mean(x_coords)
        centroid_y = np.mean(y_coords)
        return centroid_x, centroid_y
    except Exception as e:
        logging.error(f"Error in calculate_centroid: {e}")
        return None, None


# Global variables to store the centroid's Y-coordinate
fall_centroid_y = None
up_centroid_y = None
is_first_frame = True  # Flag to identify the first frame
c=0
# Updated fall detection system
def fall_detection_system(video_source):
    logging.info("Fall Detection Started")
    global fall_centroid_y, up_centroid_y, is_first_frame, y_DIFF_THRESHOLD,c
    try:
        cap = cv2.VideoCapture(video_source)

        # Curl counter variables
        counter = 0
        stage = None

        # Setup mediapipe instance
        with mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.7) as pose:
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    logging.warning("Video capture ended or failed.")
                    break

                # Recolor image to RGB
                image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False

                # Make detection
                results = pose.process(image)

                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark

                    # Get coordinates
                    keypoints = [
                        [landmark.x, landmark.y] for landmark in landmarks
                    ]  # List of [x, y] points

                    # Centroid calculation
                    centroid_x, centroid_y = calculate_centroid(keypoints)

                    # Get specific joint coordinates for angle calculation
                    left_ankle = [landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                                  landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
                    left_knee = [landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                                 landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
                    left_hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
                                landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]

                    right_ankle = [landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE.value].x,
                                   landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE.value].y]
                    right_knee = [landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
                                  landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].y]
                    right_hip = [landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                                 landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].y]

                    # Calculate angles
                    angle = calculate_angle(left_hip, left_knee, left_ankle)
                    angle_2 = calculate_angle(right_hip, right_knee, right_ankle)
                    logging.debug(f"Left angle: {angle}, Right angle: {angle_2}")

                    # print("y_DIFF_THRESHOLD",y_DIFF_THRESHOLD)
                    # First frame initialization
                    if is_first_frame:
                        if angle < 60 or angle_2 < 60:  # Fall state
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Initialize fall centroid
                        else:  # Up state
                            stage = "up"
                            up_centroid_y = centroid_y  # Initialize up centroid
                        is_first_frame = False  # Disable first-frame logic
                        continue  # Skip threshold checks for the first frame

                    # Logic to check fall state
                    if angle > 160 and angle_2 > 160:  # Check for "up" state
                        
                        c+=1
                        if c>=30:
                            y_DIFF_THRESHOLD=abs(fall_centroid_y - centroid_y)
                            print("DUE TO C-",y_DIFF_THRESHOLD)
                            c=0
                            stage = "up"

                        if fall_centroid_y is not None and abs(fall_centroid_y - centroid_y) > y_DIFF_THRESHOLD:
                            print("STANDING-",abs(fall_centroid_y - centroid_y))
                            stage = "up"
                            up_centroid_y = centroid_y  # Store current "up" centroid
                            y_DIFF_THRESHOLD = abs(fall_centroid_y - centroid_y)
                            print("DUE TO STANDING-",y_DIFF_THRESHOLD)
                            c=40
                            logging.info(f"Back to 'up' stage. Fall counter: {counter}")

                    if (angle < 60 or angle_2 < 60) and stage == "up":  # Check for "fall" state
                        c-=1
                        if c<0:c=0
                        
                        if up_centroid_y is not None and abs(up_centroid_y - centroid_y) >= y_DIFF_THRESHOLD:
                            send_message()
                            print("FALLING-",abs(up_centroid_y - centroid_y))
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Store current "fall" centroid
                            counter += 1
                            c=0
                            y_DIFF_THRESHOLD = abs(up_centroid_y - centroid_y)
                            print("DUE TO FALLING-",y_DIFF_THRESHOLD)
                            logging.info(f"Fall detected! Counter: {counter}")
                        elif y_DIFF_THRESHOLD-abs(up_centroid_y - centroid_y)<=0.04:
                            send_message()
                            print("FALLING-",abs(up_centroid_y - centroid_y))
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Store current "fall" centroid
                            counter += 1
                            c=0
                            y_DIFF_THRESHOLD = abs(up_centroid_y - centroid_y)
                            print("DUE TO FALLING-",y_DIFF_THRESHOLD)
                            logging.info(f"Fall detected! Counter: {counter}")


                except Exception as e:
                    logging.error(f"Error processing landmarks: {e}")

                # Render the fall counter
                cv2.rectangle(image, (0, 0), (225, 73), (245, 117, 16), -1)
                cv2.putText(image, 'Fall Count', (15, 12),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, str(counter),
                            (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(image, 'Stage', (120, 12),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, stage,
                            (120, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

                # Render mediapipe landmarks
                mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                          mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=2),
                                          mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2))

                # Display
                cv2.imshow('Fall Detection System', image)

                if cv2.waitKey(10) & 0xFF == ord('q'):
                    logging.info("Exit key pressed. Closing application.")
                    break

        cap.release()
        cv2.destroyAllWindows()
    except Exception as e:
        logging.error(f"Error in fall_detection_system: {e}")



# Function to select a video file
def select_video_file():
    global video_source
    try:
        video_source = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi")])
        if video_source:  # If a file is selected
            root.destroy()  # Close the GUI
            logging.info(f"Selected video file: {video_source}")
            fall_detection_system(resource_path(video_source))
    except Exception as e:
        logging.error(f"Error in select_video_file: {e}")


# Tkinter GUI
try:
    root = Tk()
    root.title("Select Input Source")
    root.geometry("300x150")

    label = Label(root, text="Choose your input source:", font=("Helvetica", 12))
    label.pack(pady=10)

    button1 = Button(root, text="Select Camera", command=select_camera_window)
    button1.pack(pady=5)

    button2 = Button(root, text="Select Video File", command=select_video_file)
    button2.pack(pady=5)

    root.mainloop()
except Exception as e:
    logging.error(f"Error in main Tkinter application: {e}")
