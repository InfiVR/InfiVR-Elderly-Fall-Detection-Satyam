import cv2
import mediapipe as mp
import numpy as np
import tkinter as tk
from tkinter import Tk, Button, filedialog, Label, Toplevel, Listbox, Scrollbar, simpledialog, messagebox
import logging
import os
import sys
import threading
import requests
from datetime import datetime

# Setup logging
logging.basicConfig(
    filename="fall_detector.log",  # Log file
    level=logging.DEBUG,  # Log all levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format="%(asctime)s [%(levelname)s] %(message)s",  # Format for log messages
)
logging.info("Program started.")

# Global variable for video source


# Mediapipe setup
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

#Painting
video_source = None
drawing = False  # Whether the user is drawing
brush_radius = 10  # Radius of the paintbrush
draw_mode = True  # Draw mode flag
painting_complete = False  # Flag to indicate painting is done
drawn_contours = None #To save drawn contours

# Global variables to store the centroid's Y-coordinate
fall_centroid_y = None
up_centroid_y = None
is_first_frame = True  # Flag to identify the first frame
c=0
# Updated fall detection system
h_min=0
s_min=0
v_min=0
h_max=0
s_max=0
v_max=0
filtering_complete=False

static_counter = None
previous_frame = None
static_threshold=2
static_pixels=None
min_detection_confidence=0.7
Detect_Fail_Counter=0
y_DIFF_THRESHOLD = 0.01 
overlap=None

def reset_everything():
    global video_source, drawing, brush_radius, draw_mode, painting_complete, drawn_contours, fall_centroid_y, up_centroid_y, is_first_frame, c, h_min,s_min,v_min,h_max, s_max,v_max,filtering_complete ,static_counter,previous_frame,static_threshold,static_pixels,min_detection_confidence,Detect_Fail_Counter,y_DIFF_THRESHOLD,overlap
        
    #Painting
    video_source = None
    drawing = False  # Whether the user is drawing
    brush_radius = 10  # Radius of the paintbrush
    draw_mode = True  # Draw mode flag
    painting_complete = False  # Flag to indicate painting is done
    drawn_contours = None #To save drawn contours

    # Global variables to store the centroid's Y-coordinate
    fall_centroid_y = None
    up_centroid_y = None
    is_first_frame = True  # Flag to identify the first frame
    c=0

    #HSV
    h_min=0
    s_min=0
    v_min=0
    h_max=0
    s_max=0
    v_max=0
    filtering_complete=False

    #Static
    static_counter = None
    previous_frame = None
    static_threshold=2
    static_pixels=None
    overlap=None

    #Fall detection
    min_detection_confidence=0.7
    Detect_Fail_Counter=0
    y_DIFF_THRESHOLD = 0.01 



def toggle_draw(event, x, y, flags, param):
    """Mouse callback to handle drawing on the frame."""
    global drawing

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
    elif event == cv2.EVENT_MOUSEMOVE and drawing:
        cv2.circle(param, (x, y), brush_radius, (0, 0, 255), -1)  # Draw a red circle
    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False

def nothing(x):
    pass


def ask_draw_mode():
    """Create a Tkinter popup with Yes/No buttons to ask if the user wants to draw."""
    global draw_mode
    root = Tk()
    root.title("Drawing Mode")

    def set_yes():
        """Set draw_mode to True and close the popup."""
        global draw_mode
        draw_mode = True
        root.destroy()

    def set_no():
        """Set draw_mode to False and close the popup."""
        global draw_mode
        draw_mode = False
        root.destroy()

def ask_filter_mode():
    """Create a Tkinter popup with Yes/No buttons to ask if the user wants to draw."""
    global filtering_complete
    root = Tk()
    root.title("Filtering Mode")

    def set_complete():
        """Set draw_mode to True and close the popup."""
        global filtering_complete
        filtering_complete= True
        cv2.destroyWindow("Thermal_Masking")
        root.destroy()     

    # Create label and button
    Label(root, text="Have you completed filtering?").pack(pady=10)
    Button(root, text="Yes", command=set_complete, width=10).pack(pady=20)
    # Center the window
    root.eval('tk::PlaceWindow . center')
    root.mainloop()

def paint_mode(frame):
    """Activate paint mode, allow drawing, and fill closed loops with green color."""
    global painting_complete, drawing, drawn_contours

    # Initialize the list to store contours
    drawn_contours = []

    # Create a blank image to store drawing and detect contours
    drawn_mask = np.zeros_like(frame, dtype=np.uint8)

    # Create a window for drawing
    cv2.namedWindow("Paint Mode")
    cv2.setMouseCallback("Paint Mode", toggle_draw, drawn_mask)

    while not painting_complete:
        # Display the drawing frame
        display_frame = cv2.addWeighted(frame, 0.5, drawn_mask, 0.5, 0)  # Blend original frame and drawing
        cv2.imshow("Paint Mode", display_frame)
        if cv2.getWindowProperty("Paint Mode", cv2.WND_PROP_VISIBLE) < 1:
            painting_complete = True
            break
        # Wait for the user to press 'q' to finish painting
        if cv2.waitKey(1) & 0xFF == ord("q"):
            painting_complete = True

        # Find contours in the drawn mask
        gray_mask = cv2.cvtColor(drawn_mask, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
        contours, _ = cv2.findContours(gray_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Save the contours
        drawn_contours = contours

        # Fill closed loops with green color
        for contour in contours:
            # Fill the contour area
            cv2.drawContours(frame, [contour], -1, (0, 0, 0), thickness=cv2.FILLED)

    # Close the drawing window
    cv2.destroyWindow("Paint Mode")
    return drawn_contours

def resource_path(relative_path):
    try:
        base_path=sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path,relative_path)

# Function to calculate the angle between three points
def calculate_angle(a, b, c):
    try:
        a = np.array(a)  # First
        b = np.array(b)  # Mid
        c = np.array(c)  # End

        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
        angle = np.abs(radians * 180.0 / np.pi)

        if angle > 180.0:
            angle = 360 - angle

        logging.debug(f"Calculated angle: {angle}")
        return angle
    except Exception as e:
        logging.error(f"Error in calculate_angle: {e}")
        return None

import requests
from datetime import datetime

def get_current_datetime():
    now = datetime.now()
    return now.strftime("%m/%d/%y,%H:%M:%S")

def send_message():
    url = "http://elderly-healthcare.infivr.com/api/events/create"
    payload = {
        "eventName": "Fall",
        "userName": "Satyam",
        "applicationName": "FALL_DETECTOR",
        "eventTime": get_current_datetime(),
        "severity": "high",
        "sensorId": "1"
    }
    headers = {}
    response = requests.request("POST", url, headers=headers, data=payload)
    print(response.text)

# Function to list all available cameras
def list_cameras():
    try:
        index = 0
        available_cameras = []
        while True:
            cap = cv2.VideoCapture(index)
            if not cap.read()[0]:  # If the camera cannot be opened, stop checking
                break
            available_cameras.append(f"Camera {index}")
            cap.release()
            index += 1
        logging.info(f"Available cameras: {available_cameras}")
        return available_cameras
    except Exception as e:
        logging.error(f"Error in list_cameras: {e}")
        return []


# Function to open a new window to select a camera
def select_camera_window():
    global video_source
    print(video_source)

    try:
        # Create a new window
        camera_window = Toplevel(root)
        camera_window.title("Select Camera")
        camera_window.geometry("300x300")

        # Label
        label = Label(camera_window, text="Select a Camera", font=("Helvetica", 12))
        label.pack(pady=10)

        # Listbox to show available cameras
        camera_listbox = Listbox(camera_window, width=30, height=10)
        camera_listbox.pack(pady=10)

        # Add a scrollbar
        scrollbar = Scrollbar(camera_window, orient="vertical", command=camera_listbox.yview)
        scrollbar.pack(side="right", fill="y")
        camera_listbox.config(yscrollcommand=scrollbar.set)

        # List available cameras
        cameras = list_cameras()
        for cam in cameras:
            camera_listbox.insert("end", cam)

        # Function to set the selected camera and close the window
        def confirm_camera():
            selected_index = camera_listbox.curselection()
            if selected_index:
                video_source = int(selected_index[0])  # Get the camera index
                camera_window.destroy()  # Close the camera selection window
                root.destroy()  # Close the main window
                logging.info(f"Selected camera: {video_source}")
                fall_detection_system(video_source)

        # Button to confirm the selection
        confirm_button = Button(camera_window, text="Confirm", command=confirm_camera)
        confirm_button.pack(pady=10)

    except Exception as e:
        logging.error(f"Error in select_camera_window: {e}")


# Function to process the fall detection system
# Function to calculate the centroid of all joint points
# Threshold for Y-difference
 # Adjust this value based on the scaling of your coordinate system
# Function to calculate the centroid of a list of points
def calculate_centroid(points):
    try:
        x_coords = [point[0] for point in points]
        y_coords = [point[1] for point in points]
        centroid_x = np.mean(x_coords)
        centroid_y = np.mean(y_coords)
        return centroid_x, centroid_y
    except Exception as e:
        logging.error(f"Error in calculate_centroid: {e}")
        return None, None

def fall_detection_system(video_source):
    logging.info("Fall Detection Started")
    global fall_centroid_y, up_centroid_y, is_first_frame, y_DIFF_THRESHOLD,c,draw_mode,filtering_complete,h_min, s_min, v_min, static_threshold,static_counter,previous_frame,static_pixels,min_detection_confidence,Detect_Fail_Counter,overlap
    try:
        if not painting_complete and draw_mode: draw_cap=cv2.VideoCapture(video_source)
        while draw_cap.isOpened() and not painting_complete and draw_mode:
            ret, frame = draw_cap.read()
            if not ret:
                logging.warning("Video capture ended or failed.")
                break

            # Capture the first frame
            captured_frame = frame.copy()  # Copy the frame to work on it

            # Reset the video to the 0th frame
            draw_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            draw_cap.release()  # Release draw_cap as we no longer need it

            # Perform drawing on the captured frame
            if draw_mode:
                global drawn_contours
                drawn_contours = paint_mode(captured_frame)  # Drawing occurs on the captured frame
                if drawn_contours:
                    print("Drawn contours processed.")
            else:
                break 
        # Create a window
        cv2.namedWindow("Trackbars")
        # Create trackbars for HSV min and max values
        cv2.createTrackbar("H Min", "Trackbars", 0, 179, nothing)
        cv2.createTrackbar("H Max", "Trackbars", 179, 179, nothing)
        cv2.createTrackbar("S Min", "Trackbars", 0, 255, nothing)
        cv2.createTrackbar("S Max", "Trackbars", 255, 255, nothing)
        cv2.createTrackbar("V Min", "Trackbars", 0, 255, nothing)
        cv2.createTrackbar("V Max", "Trackbars", 255, 255, nothing)    
        # cv2.namedWindow("Settings")
        # cv2.createTrackbar("Brightness Threshold MID", "Settings", 15, 240, nothing)
        n_static=0
        mid_threshold=63
        best=None
        while not filtering_complete:
                filter_cap=cv2.VideoCapture(video_source)
                ret, frame = filter_cap.read()
                # Capture the first frame
                captured_frame = frame.copy()  # Copy the frame to work on it
                # Reset the video to the 0th frame
                filter_cap.release()  # Release draw_cap as we no longer need it
                filter_cap.set(cv2.CAP_PROP_POS_FRAMES, 0) 
            # Recolor image to RGB
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                # Get current positions of trackbars
                h_min = cv2.getTrackbarPos("H Min", "Trackbars")
                h_max = cv2.getTrackbarPos("H Max", "Trackbars")
                s_min = cv2.getTrackbarPos("S Min", "Trackbars")
                s_max = cv2.getTrackbarPos("S Max", "Trackbars")
                v_min = cv2.getTrackbarPos("V Min", "Trackbars")
                v_max = cv2.getTrackbarPos("V Max", "Trackbars")
                lower_bound = np.array([h_min, s_min, v_min])
                upper_bound = np.array([h_max, s_max, v_max])
                mask = cv2.inRange(hsv, lower_bound, upper_bound)
                thermal_image = cv2.cvtColor(captured_frame, cv2.COLOR_BGR2RGB)
                thermal_result = cv2.bitwise_and(thermal_image, thermal_image, mask=mask)
                cv2.imshow("Thermal_Masking",thermal_result)
                if cv2.waitKey(1) & 0xFF == ord('q'):  # 'c' to call the popup
                    filtering_complete= True
                    cv2.destroyWindow("Thermal_Masking")
                    cv2.destroyWindow("Trackbars")

        cap = cv2.VideoCapture(video_source)
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

        # Curl counter variables
        counter = 0
        stage = None
        final_result=None
        # Setup mediapipe instance
        with mp_pose.Pose(min_detection_confidence=min_detection_confidence, min_tracking_confidence=0.8) as pose:
            
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    logging.warning("Video capture ended or failed.")
                    break
                
                # Create the mask based on trackbar positions
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                lower_bound = np.array([h_min, s_min, v_min])
                upper_bound = np.array([h_max, s_max, v_max])
                mask = cv2.inRange(hsv, lower_bound, upper_bound)
                thermal_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                thermal_result = cv2.bitwise_and(thermal_image, thermal_image, mask=mask)
                # cv2.imshow("Thermal_Masking",thermal_result)
                image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False

                gray_frame = cv2.cvtColor(thermal_result.copy(), cv2.COLOR_BGR2GRAY)
                if static_counter is None:
                    static_counter = np.zeros_like(gray_frame, dtype=np.uint16)
                    overlap = gray_frame.copy()
                if previous_frame is not None:
                    if n_static<10:
                        n_static+=1
                    elif n_static==10:
                        n_static=0
                        cv2.imshow("overlap",overlap)
                        overlap = gray_frame.copy()
                        
                    static_mask = gray_frame == previous_frame
                    static_counter[static_mask] += 1
                    static_counter[~static_mask] = 0
                    brightness_threshold_LEAST = mid_threshold - 15 
                    brightness_threshold_MAX = mid_threshold + 15
                    static_pixels = (static_counter > 0) & (brightness_threshold_MAX > gray_frame) & (gray_frame > brightness_threshold_LEAST)
                    gray_frame[static_pixels] = 0
                    overlap[static_pixels] = 0
                    final_result=cv2.cvtColor(overlap,cv2.COLOR_GRAY2RGB)
                    results = pose.process(final_result)
                previous_frame = gray_frame.copy()
                # cv2.imshow('Processed Frame', gray_frame)
                thermal_result[static_pixels]=(0,0,0)
                gray_frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2RGB)
                if final_result is None: results = pose.process(gray_frame)
                if not results.pose_landmarks and min_detection_confidence>=0.1 :
                    min_detection_confidence-=0.1
                elif min_detection_confidence<0.7:
                    min_detection_confidence+=0.1

                if results.pose_landmarks and mid_threshold>15 and best==None:
                    mid_threshold-=1
                    best = mid_threshold
                elif best==None and not results.pose_landmarks:best=mid_threshold
                else:
                    mid_threshold=best
                    mid_threshold+=1


                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark

                    # Get coordinates
                    keypoints = [
                        [landmark.x, landmark.y] for landmark in landmarks
                    ]  # List of [x, y] points

                    # Centroid calculation
                    centroid_x, centroid_y = calculate_centroid(keypoints)

                    # Get specific joint coordinates for angle calculation
                    left_ankle = [landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                                landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
                    left_knee = [landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                                landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
                    left_hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
                                landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]

                    right_ankle = [landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE.value].x,
                                landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE.value].y]
                    right_knee = [landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
                                landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].y]
                    right_hip = [landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                                landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].y]

                    # Calculate angles
                    angle = calculate_angle(left_hip, left_knee, left_ankle)
                    angle_2 = calculate_angle(right_hip, right_knee, right_ankle)
                    logging.debug(f"Left angle: {angle}, Right angle: {angle_2}")

                    # print("y_DIFF_THRESHOLD",y_DIFF_THRESHOLD)
                    # First frame initialization
                    if is_first_frame:
                        if angle < 60 or angle_2 < 60:  # Fall state
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Initialize fall centroid
                        else:  # Up state
                            stage = "up"
                            up_centroid_y = centroid_y  # Initialize up centroid
                        is_first_frame = False  # Disable first-frame logic
                        continue  # Skip threshold checks for the first frame
                    
                    if drawn_contours:  # Check if the user has drawn contours in the first frame
                        left_hip_point = (int(left_hip[0] * frame.shape[1]), int(left_hip[1] * frame.shape[0]))
                        right_hip_point = (int(right_hip[0] * frame.shape[1]), int(right_hip[1] * frame.shape[0]))

                        left_inside = False
                        right_inside = False

                        # Check each contour for inclusion
                        for contour in drawn_contours:
                            if cv2.pointPolygonTest(contour, left_hip_point, False) >= 0:  # Check if left hip is inside
                                left_inside = True
                            if cv2.pointPolygonTest(contour, right_hip_point, False) >= 0:  # Check if right hip is inside
                                right_inside = True

                        # Proceed only if both hips are inside at least one contour
                        if left_inside and right_inside:
                            logging.info("Both hips are inside the drawn contours. Continuing...")
                            continue
                    # Logic to check fall state
                    if angle > 160 and angle_2 > 160:  # Check for "up" state
                        
                        c+=1
                        if c>=30:
                            y_DIFF_THRESHOLD=abs(fall_centroid_y - centroid_y)
                            print("DUE TO C-",y_DIFF_THRESHOLD)
                            c=0
                            stage = "up"

                        if fall_centroid_y is not None and abs(fall_centroid_y - centroid_y) > y_DIFF_THRESHOLD:
                            print("STANDING-",abs(fall_centroid_y - centroid_y))
                            stage = "up"
                            up_centroid_y = centroid_y  # Store current "up" centroid
                            y_DIFF_THRESHOLD = abs(fall_centroid_y - centroid_y)
                            print("DUE TO STANDING-",y_DIFF_THRESHOLD)
                            c=40
                            logging.info(f"Back to 'up' stage. Fall counter: {counter}")

                    if (angle < 60 or angle_2 < 60) and stage == "up":  # Check for "fall" state
                        c-=1
                        if c<0:c=0
                        
                        if up_centroid_y is not None and abs(up_centroid_y - centroid_y) >= y_DIFF_THRESHOLD:
                            send_message()
                            print("FALLING-",abs(up_centroid_y - centroid_y))
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Store current "fall" centroid
                            counter += 1
                            c=0
                            y_DIFF_THRESHOLD = abs(up_centroid_y - centroid_y)
                            print("DUE TO FALLING-",y_DIFF_THRESHOLD)
                            logging.info(f"Fall detected! Counter: {counter}")
                        elif y_DIFF_THRESHOLD-abs(up_centroid_y - centroid_y)<=0.04:
                            send_message()
                            print("FALLING-",abs(up_centroid_y - centroid_y))
                            stage = "fall"
                            fall_centroid_y = centroid_y  # Store current "fall" centroid
                            counter += 1
                            c=0
                            y_DIFF_THRESHOLD = abs(up_centroid_y - centroid_y)
                            print("DUE TO FALLING-",y_DIFF_THRESHOLD)
                            logging.info(f"Fall detected! Counter: {counter}")


                except Exception as e:
                    logging.error(f"Error processing landmarks: {e}")
                # Render mediapipe landmarks
                mp_drawing.draw_landmarks(thermal_result, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                        mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=2),
                                        mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2))
                
                # Render the fall counter
                cv2.rectangle(thermal_result, (0, 0), (225, 73), (245, 117, 16), -1)
                cv2.putText(thermal_result, 'Fall Count', (15, 12),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(thermal_result, str(counter),
                            (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.putText(thermal_result, 'Stage', (120, 12),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(thermal_result, stage,
                            (120, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

                
                
                # Display
                cv2.imshow('Fall Detection System', thermal_result)
                
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    logging.info("Exit key pressed. Closing application.")
                    break

            cap.release()
            cv2.destroyAllWindows()
    except Exception as e:
        logging.error(f"Error in fall_detection_system: {e}")



# Function to select a video file
def select_video_file():
    reset_everything()
    global video_source
    try:
        video_source = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi")])
        if video_source:  # If a file is selected
            root.destroy()  # Close the GUI
            logging.info(f"Selected video file: {video_source}")
            fall_detection_system(resource_path(video_source))
    except Exception as e:
        logging.error(f"Error in select_video_file: {e}")

should_restart = False

def restart_program():
    # Display the restart dialog box
    response = messagebox.askyesno("Restart", "Do you want to restart?")
    if response:  # If the user clicks "Yes" 
        main()  # Restart the main function
    else:  # If the user clicks "No"
        root.destroy()  # Exit the program

def main():
    global root
    root = Tk()
    root.title("Select Input Source")
    root.geometry("300x150")

    label = Label(root, text="Choose your input source:", font=("Helvetica", 12))
    label.pack(pady=10)

    button1 = Button(root, text="Select Camera", command=select_camera_window)
    button1.pack(pady=5)

    button2 = Button(root, text="Select Video File", command=select_video_file)
    button2.pack(pady=5)

    root.protocol("WM_DELETE_WINDOW", restart_program)  # Handle close button
    root.mainloop()

    # After the main loop ends, ask if the user wants to restart
    restart_program()

# Run the application
main()
